import Group from './Group'

export const mainGroup = new Group()
