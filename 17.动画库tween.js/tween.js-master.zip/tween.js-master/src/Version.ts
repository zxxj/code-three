const VERSION = '18.6.4'
export default VERSION
